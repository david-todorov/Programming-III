var searchData=
[
  ['getactualstock_0',['getActualStock',['../class_stock.html#a5797a7362a8d1a9f4992e3df1d2f7224',1,'Stock']]],
  ['getarticlenumber_1',['getArticleNumber',['../class_stock.html#ae84af4d570d71c0db8b77d25fb4a2a42',1,'Stock']]],
  ['getconsumption_2',['getConsumption',['../class_stock.html#af326573cfa746cdab351c4e224b0add3',1,'Stock']]],
  ['getcostprice_3',['getCostPrice',['../class_article.html#a7e0f3ee42eb024b52e718f3e99f2ffa9',1,'Article']]],
  ['getdescription_4',['getDescription',['../class_article.html#a7fcbab72e42bec69bfa00ce209a1f735',1,'Article']]],
  ['getmaximumstock_5',['getMaximumStock',['../class_stock.html#a7b9cfe47b15a35f16f108b92b1c3cba5',1,'Stock']]],
  ['getnumberofarticle_6',['getNumberOfArticle',['../class_article.html#a1f809c1da784156cbad52ecb5c815fd0',1,'Article']]],
  ['getorderduration_7',['getOrderDuration',['../class_article.html#a19bff91f43fe685f994587f4f77fc064',1,'Article']]]
];
