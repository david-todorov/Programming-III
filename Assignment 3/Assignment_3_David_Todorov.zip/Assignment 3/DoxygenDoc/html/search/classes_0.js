var searchData=
[
  ['article_0',['Article',['../class_article.html',1,'']]]
];
