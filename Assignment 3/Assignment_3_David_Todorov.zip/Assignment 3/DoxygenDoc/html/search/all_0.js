var searchData=
[
  ['addingwhitespaces_0',['addingWhiteSpaces',['../_test_8cpp.html#a7c6cbcdb1b39c2e81e1569c81c953a32',1,'Test.cpp']]],
  ['article_1',['Article',['../class_article.html',1,'Article'],['../class_article.html#a975a41a91c4850a128f6ae9f58502bdf',1,'Article::Article()']]],
  ['article_2ecpp_2',['Article.cpp',['../_article_8cpp.html',1,'']]],
  ['article_2eh_3',['Article.h',['../_article_8h.html',1,'']]]
];
