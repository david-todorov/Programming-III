var _macro_8cpp =
[
    [ "QSUMME", "_macro_8cpp.html#a0d4ec06985d527664f03dbaec7b39416", null ],
    [ "main", "_macro_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];