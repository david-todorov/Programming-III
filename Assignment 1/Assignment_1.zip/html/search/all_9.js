var searchData=
[
  ['qsumme_0',['QSUMME',['../_macro_8cpp.html#a0d4ec06985d527664f03dbaec7b39416',1,'Macro.cpp']]]
];
