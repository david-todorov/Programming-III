var searchData=
[
  ['kl1_0',['KL1',['../class_k_l1.html#aa12c2ab3a5f790604d9e58b0e907a6a5',1,'KL1::KL1()'],['../class_k_l1.html#a8c0e96f76e7adf1989c4dcae6441275c',1,'KL1::KL1(string n, int v)']]]
];
