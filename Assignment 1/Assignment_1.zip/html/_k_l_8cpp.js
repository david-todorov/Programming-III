var _k_l_8cpp =
[
    [ "KL1", "class_k_l1.html", "class_k_l1" ],
    [ "KL2", "class_k_l2.html", "class_k_l2" ],
    [ "main", "_k_l_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];