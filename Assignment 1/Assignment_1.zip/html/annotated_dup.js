var annotated_dup =
[
    [ "CA", "class_c_a.html", "class_c_a" ],
    [ "CB", "class_c_b.html", "class_c_b" ],
    [ "KL1", "class_k_l1.html", "class_k_l1" ],
    [ "KL2", "class_k_l2.html", "class_k_l2" ]
];