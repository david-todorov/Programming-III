var searchData=
[
  ['previous_0',['previous',['../struct_d_list_elem.html#a0a18a60ce5c9d021999e0477ec2aea35',1,'DListElem']]]
];
