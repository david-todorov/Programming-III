var searchData=
[
  ['main_0',['main',['../_exercise__2__3___doubly_linked_list_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'Exercise_2_3_DoublyLinkedList.cpp']]]
];
