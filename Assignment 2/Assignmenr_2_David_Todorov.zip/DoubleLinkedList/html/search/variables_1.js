var searchData=
[
  ['info_0',['info',['../struct_d_list_elem.html#a0724bdb84ec2cdcd2f3fc8f44ff48624',1,'DListElem']]]
];
