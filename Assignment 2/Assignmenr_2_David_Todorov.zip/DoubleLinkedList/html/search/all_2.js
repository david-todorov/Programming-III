var searchData=
[
  ['first_0',['first',['../struct_d_list.html#a2cd68ef7aac68deab5d21e21e601126a',1,'DList']]]
];
