var searchData=
[
  ['last_0',['last',['../struct_d_list.html#a87a4b8602f06934b5c079972cbb09484',1,'DList']]]
];
