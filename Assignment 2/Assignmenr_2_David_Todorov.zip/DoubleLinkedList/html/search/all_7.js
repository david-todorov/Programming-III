var searchData=
[
  ['next_0',['next',['../struct_d_list_elem.html#a6bdc0e19cb86aee6ad178aeb51353b3d',1,'DListElem']]]
];
