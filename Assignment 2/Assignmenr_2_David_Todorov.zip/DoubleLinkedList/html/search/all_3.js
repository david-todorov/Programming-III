var searchData=
[
  ['get_0',['get',['../dlist_8cpp.html#a98fa9cf9e2fcd77d6dbc3165834ef066',1,'get(DList &amp;dl, int &amp;val):&#160;dlist.cpp'],['../dlist_8h.html#a98fa9cf9e2fcd77d6dbc3165834ef066',1,'get(DList &amp;dl, int &amp;val):&#160;dlist.cpp']]]
];
